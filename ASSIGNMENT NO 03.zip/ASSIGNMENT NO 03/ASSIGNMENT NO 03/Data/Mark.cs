﻿using System.ComponentModel.DataAnnotations;

namespace ASSIGNMENT_NO_03.data
{
    public class Mark
    {
        [Key]
        public int MarkId { get; set; }
        public int EnrolledCid { get; set; }
        public Enrolled Enrolled { get; set; }
        // Additional mark-related properties
    }
}
