﻿using System.ComponentModel.DataAnnotations;
using System.Runtime.InteropServices;
using System.Security.Claims;

namespace ASSIGNMENT_NO_03.data
{
    public class Faculty
    {
        [Key]
        public int Fid { get; set; }
        public string Fname { get; set; }
        public int Deptid { get; set; }
        public int Standing { get; set; }
        public ICollection<Class> Classes { get; set; }
    }
}
